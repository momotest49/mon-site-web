/**
 * SHIFT² — Official Website Interactive Controller
 * Premium Interactions, Kinetic Hero Canvas, Smooth Scroll, Form Validation
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // -------------------------------------------------------------------------
  // 1. NAVBAR SCROLL STATE & ACTIVE LINK TRACKING
  // -------------------------------------------------------------------------
  const navbar = document.getElementById('navbar');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  const handleScroll = () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // Active section observer
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const currentId = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${currentId}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, {
    rootMargin: '-30% 0px -60% 0px'
  });

  sections.forEach(section => sectionObserver.observe(section));

  // -------------------------------------------------------------------------
  // 2. MOBILE MENU CONTROLLER
  // -------------------------------------------------------------------------
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileLinks = document.querySelectorAll('.mobile-link');

  const toggleMobileMenu = (forceClose = false) => {
    const isOpen = forceClose ? false : !mobileMenu.classList.contains('open');
    if (isOpen) {
      mobileMenu.classList.add('open');
      mobileMenuBtn.classList.add('active');
      mobileMenuBtn.setAttribute('aria-expanded', 'true');
      mobileMenu.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    } else {
      mobileMenu.classList.remove('open');
      mobileMenuBtn.classList.remove('active');
      mobileMenuBtn.setAttribute('aria-expanded', 'false');
      mobileMenu.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  };

  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', () => toggleMobileMenu());
  }

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => toggleMobileMenu(true));
  });

  // -------------------------------------------------------------------------
  // 3. SERVICE CTA TO CONTACT PRE-FILL
  // -------------------------------------------------------------------------
  const serviceCtaButtons = document.querySelectorAll('.select-service-btn');
  const serviceSelect = document.getElementById('serviceNeed');

  serviceCtaButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const selectedNeed = btn.getAttribute('data-need');
      if (selectedNeed && serviceSelect) {
        serviceSelect.value = selectedNeed;
        
        // Gentle highlight animation on select
        serviceSelect.style.borderColor = '#16C784';
        serviceSelect.style.boxShadow = '0 0 0 3px rgba(22, 199, 132, 0.25)';
        setTimeout(() => {
          serviceSelect.style.borderColor = '';
          serviceSelect.style.boxShadow = '';
        }, 1800);
      }
    });
  });

  // -------------------------------------------------------------------------
  // 4. CONTACT FORM VALIDATION & SUBMISSION
  // -------------------------------------------------------------------------
  const contactForm = document.getElementById('contactForm');
  const submitBtn = document.getElementById('submitBtn');
  const formSuccess = document.getElementById('formSuccessMessage');

  const validateEmail = (email) => {
    return String(email)
      .toLowerCase()
      .match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
  };

  const showError = (fieldId, message) => {
    const field = document.getElementById(fieldId);
    const errorElem = document.getElementById(`${fieldId}Error`);
    if (field) field.classList.add('is-invalid');
    if (errorElem) errorElem.textContent = message;
  };

  const clearError = (fieldId) => {
    const field = document.getElementById(fieldId);
    const errorElem = document.getElementById(`${fieldId}Error`);
    if (field) field.classList.remove('is-invalid');
    if (errorElem) errorElem.textContent = '';
  };

  if (contactForm) {
    ['fullName', 'email', 'phone', 'serviceNeed', 'projectMessage'].forEach(fieldId => {
      const field = document.getElementById(fieldId);
      if (field) {
        field.addEventListener('input', () => clearError(fieldId));
        field.addEventListener('change', () => clearError(fieldId));
      }
    });

    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      const fullName = document.getElementById('fullName').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const serviceNeed = document.getElementById('serviceNeed').value;
      const projectMessage = document.getElementById('projectMessage').value.trim();

      if (!fullName) {
        showError('fullName', 'Veuillez renseigner votre nom complet.');
        isValid = false;
      }

      if (!email) {
        showError('email', 'Veuillez renseigner votre adresse e-mail.');
        isValid = false;
      } else if (!validateEmail(email)) {
        showError('email', 'Veuillez saisir une adresse e-mail valide.');
        isValid = false;
      }

      if (!phone) {
        showError('phone', 'Veuillez indiquer un numéro de téléphone.');
        isValid = false;
      }

      if (!serviceNeed) {
        showError('serviceNeed', 'Veuillez choisir un service ou domaine.');
        isValid = false;
      }

      if (!projectMessage) {
        showError('projectMessage', 'Veuillez décrire brièvement votre projet.');
        isValid = false;
      }

      if (isValid) {
        // Button loading state
        submitBtn.disabled = true;
        const originalBtnContent = submitBtn.innerHTML;
        submitBtn.innerHTML = `
          <span>Transmission en cours...</span>
          <svg class="spinner" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle><path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"></path></svg>
        `;

        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnContent;
          contactForm.reset();
          if (formSuccess) {
            formSuccess.style.display = 'flex';
            formSuccess.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        }, 1000);
      }
    });
  }

  // -------------------------------------------------------------------------
  // 5. SCROLL REVEAL MICRO-ANIMATIONS
  // -------------------------------------------------------------------------
  const revealElements = document.querySelectorAll('.reveal-elem, .pillar-card, .service-card, .step-card, .client-card');

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -40px 0px'
  });

  revealElements.forEach((el, index) => {
    el.classList.add('reveal-elem');
    el.style.transitionDelay = `${(index % 4) * 0.1}s`;
    revealObserver.observe(el);
  });

  // -------------------------------------------------------------------------
  // 6. KINETIC HERO CANVAS (LIGNES DE TRAJECTOIRES & NOEUDS SHIFT)
  // -------------------------------------------------------------------------
  const canvas = document.getElementById('kineticCanvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width, height;
    let particles = [];
    const particleCount = 28;

    const resize = () => {
      width = canvas.width = canvas.parentElement.offsetWidth;
      height = canvas.height = canvas.parentElement.offsetHeight;
    };

    window.addEventListener('resize', resize, { passive: true });
    resize();

    class Particle {
      constructor() {
        this.reset();
      }

      reset() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.2) * 0.6; // Slight directional shift towards right
        this.vy = (Math.random() - 0.5) * 0.5;
        this.radius = Math.random() * 2 + 1;
        this.alpha = Math.random() * 0.4 + 0.2;
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;
      }

      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(18, 168, 107, ${this.alpha * 0.6})`;
        ctx.fill();
      }
    }

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle());
    }

    let isCanvasVisible = true;
    const canvasObserver = new IntersectionObserver(([entry]) => {
      isCanvasVisible = entry.isIntersecting;
    });
    canvasObserver.observe(canvas);

    const animate = () => {
      if (isCanvasVisible) {
        ctx.clearRect(0, 0, width, height);

        // Draw connecting trajectories between nearby nodes
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 130) {
              const alpha = (1 - dist / 130) * 0.22;
              ctx.beginPath();
              ctx.moveTo(particles[i].x, particles[i].y);
              ctx.lineTo(particles[j].x, particles[j].y);
              ctx.strokeStyle = `rgba(18, 168, 107, ${alpha})`;
              ctx.lineWidth = 1;
              ctx.stroke();
            }
          }
        }

        particles.forEach(p => {
          p.update();
          p.draw();
        });
      }

      requestAnimationFrame(animate);
    };

    animate();
  }
});
